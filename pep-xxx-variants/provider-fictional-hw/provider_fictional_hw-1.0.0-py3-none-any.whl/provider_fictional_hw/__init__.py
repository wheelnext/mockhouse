"A Fictional Variant Provider Plugin for the `fictional_hw` namespace"

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

__version__ = "1.0.0"
