"""
sandbox-project - Example flit package with variants
"""

__version__ = "3.0.0.dev1"
