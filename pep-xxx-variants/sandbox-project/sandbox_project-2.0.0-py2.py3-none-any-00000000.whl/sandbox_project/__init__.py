"""
sandbox-project - Example flit package with variants
"""

__version__ = "2.0.0"
