"""
sandbox-project - Example flit package with variants
"""

__version__ = "1.0.0"
