#!/usr/bin/env python

import importlib.metadata

__version__ = importlib.metadata.version("provider_fictional_tech")
