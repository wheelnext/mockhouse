"A Fictional Variant Provider Plugin for the `fictional_tech` namespace"

__version__ = "1.0.0"
